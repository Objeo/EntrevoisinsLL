package com.openclassrooms.entrevoisins.service;

import com.openclassrooms.entrevoisins.model.Neighbour;

import java.util.ArrayList;
import java.util.List;

/**
 * Dummy mock for the Api
 */
public class DummyNeighbourApiService implements  NeighbourApiService {

    private List<Neighbour> neighbours = DummyNeighbourGenerator.generateNeighbours();
    private List<Neighbour> favorites = new ArrayList<>();


    /**
     * {@inheritDoc}
     */
    @Override
    public List<Neighbour> getNeighbours() {
        return neighbours;
    }

    @Override
    public List<Neighbour> getFavorite() {
        return favorites;
    }

    @Override
    public void addToFavorite(Neighbour neighbour) {
        //On ajoute le voisin a la liste favorites aprés avoir changer le statut en true
        if (!favorites.contains(neighbour)){
            neighbour.setFavorite(true);
            favorites.add(neighbour);

        }
        //Changer le statut du voisin dans la liste initiale neighbours
        for (Neighbour n: neighbours){
            if (n.equals(neighbour)){
                n.setFavorite(true);
            }
        }
    }

    @Override
    public void removeFromFavorite(Neighbour neighbour) {
        if (favorites.contains(neighbour)){
        favorites.remove(neighbour);
        }


    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void deleteNeighbour(Neighbour neighbour) {
        neighbours.remove(neighbour);
    }

    /**
     * {@inheritDoc}
     * @param neighbour
     */
    @Override
    public void createNeighbour(Neighbour neighbour) {
        neighbours.add(neighbour);
    }
}
